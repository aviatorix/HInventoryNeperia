angular.module("myApp", [ 'ngRoute' ])

.config(['$routeProvider', function($routeProvider) {
    $routeProvider
   
    .when('/home', {
        templateUrl: 'views/home.html',
        controller: 'homeCtrl',
        controllerAs: 'vr'
    })
    .when('/register', {
        templateUrl: 'views/register.html',
        controller: 'registerCtrl',
        controllerAs: 'vrg'
    })
    .when('/login', {
        templateUrl: 'views/login.html',
        controller: 'loginCtrl',
        controllerAs: 'vlg'
    })
    .when('/showDevices', {
        templateUrl: 'views/showDevices.html',
        controller: 'showDevicesCtrl',
        controllerAs: 'vsd'
    })
    .otherwise({
        redirectTo:'/home'
    });
}]);