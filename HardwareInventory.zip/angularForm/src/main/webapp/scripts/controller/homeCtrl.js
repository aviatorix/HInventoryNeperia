var app = angular.module("myApp");

app.controller('homeCtrl', ['$scope','$location', homeCtrl]); 

app.directive('hw', function() {
	return {template: '<h1> hello world!</h1>'};
})



function homeCtrl($scope, $location) {
	console.log("sono qui: homeCtrl");
	$scope.redirect = redirect;
	$scope.redirectLog = redirectLog;

	function redirect(path) {
		console.log("redirect");
		$location.path(path);
	}

	function redirectLog(path) {
		console.log("redirectLog");
		$location.path(path);
	}

}

