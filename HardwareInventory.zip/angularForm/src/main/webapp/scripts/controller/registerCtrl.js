var app = angular.module("myApp")

app.controller('registerCtrl', [ '$scope', '$http', regCtrl,]);

regCtrl.$inject = ['serviceReg'];

function regCtrl($scope, $http) {
	console.log("registerController");
	$scope.update = update;
	$scope.reset = reset;
	//$scope.closeMyAlert = closeMyAlert;
	
	user:  {
		name: ''
			surname: ''
				email: ''
					password: ''
	}


	function update(user) {
		$scope.click= true;
		registrationService($scope, user, $http);
	}

	function reset() {
		console.log("$scope.click: "+$scope.click);
		$scope.click= false;
		registrationService($scope);
	}

}