'use strict';

var app = angular.module('myApp');
app.controller('loginCtrl', ['$scope', '$http', '$location', logCtrl]);

logCtrl.$inject = ['serviceLog']; 

function logCtrl($scope, $http, $location) {
	console.log("loginController");	
	console.log(window);
	$scope.login = login;
	$scope.redirect = redirect;
	
	function login(user) {
		$scope.click = true;
		loginService($scope, $http,  user);
	}

	function reset() {
		console.log("$scope.click: "+$scope.click);
		$scope.click= false;
		registrationService($scope);
	}
	
	function redirect(path) {
		console.log("redirect");
		$location.path(path);
	}
	
	
}







