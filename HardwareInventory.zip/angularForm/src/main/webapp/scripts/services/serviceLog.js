'use strict';

var app = angular.module('myApp')
app.service('serviceLog',  [loginService]);

loginService.$inject = ['$scope', '$http', 'user'];

function loginService($scope, $http, user) {
	console.log("loginService");
	console.log(window.localStorage);
	var token =""; 
	//var seen = true;
	
	let message = [];

	if ($scope.click == true) {login()};
	if ($scope.click == false) {reset()};

	function login() {
		console.log("loginInService");
		console.log(user);
		$http.post('http://localhost:8080/Hinventory/rest/log/user', {
			email: user.email,
			password: user.password
		})
		.then((response) => {
			console.log("response", response);
			console.log("response.data.message:", response.data.message)

			if (response.data.message === "email doesnt't exist!") {
				message = {text: "Email doesnt't exist!"};
				toastr.warning(message.text);
				message = {text: "Maybe you aren't registered. Sign in!"};
				toastr.info(message.text);
			}
			else
				if (response.data.message === "Error, Access Denied!") {
					message = {text: "Error, Access Denied!"};
					toastr.error(message.text);
					message = {text: "Verify your credentials"};
					toastr.warning(message.text);
				}
				else 
					if (response.data.message === "User Found, Access Granted!") {
						message = {text: "User Found, Access Granted!"};
						toastr.success(message.text);
						//provvisorio.
						window.localStorage.setItem("token", JSON.stringify(response.data.token));
						token = JSON.parse(window.localStorage.getItem("token"));
						$scope.redirect('/home');
					
					}

		})
	}

	function reset() {
		$scope.master = {};
		console.log("function: reset()");
		$scope.user = angular.copy($scope.master);
	}

	reset();
}
