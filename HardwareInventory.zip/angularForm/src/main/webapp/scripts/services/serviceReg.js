
var app = angular.module("myApp");

app.service('serviceReg',  [registrationService]);

registrationService.$inject = ['$scope', 'user', '$http'];

function registrationService ($scope, user, $http) {
	//validation form
	console.log("registrationService");
	let message = [];

	if($scope.click === true) {
		updateService();
	}
	else 
		if ($scope.click === false) {
			reset();
		} 


	function updateService() {

		$http.post('http://localhost:8080/Hinventory/rest/reg/user', {
			name: user.name,
			surname: user.surname,
			email: user.email,
			password: user.password
		})
		.then((response) => {
			console.log("response", response);
			console.log("response.data.message:", response.data.message)

			if (response.data.message === "email already in use") {
				message = {text: "Sorry! Email already in use!"};
				toastr.error(message.text);
			}
			else {
				message = {text: "Well done! Your registration has been successful"};
				toastr.success(message.text);
			}

		})
		
		reset();
	}


	function reset() {
		$scope.master = {};
		console.log("function: reset()");
		$scope.user = angular.copy($scope.master);
		message = {text: "Fill out the form to register"};
		toastr.info(message.text);
		message = {text: "Remember that the e-mail must be with this structure: 'nameuser@domain.com' "};
		toastr.warning(message.text);
	}

	
}