package com.neperiagroup.controllerApiJersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.codehaus.jettison.json.JSONObject;
import com.neperiagroup.connectDB.SubmitLogin;

@Path("log")
public class LoginUser extends SubmitLogin {
	@POST
	@Path("user")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject log(JSONObject req) throws Exception {
		
		System.out.println(req);
		System.out.println(req.get("email"));
		System.out.println(req.get("password"));
		JSONObject res = SubmitLogin.SubmitActionPerformed(req.get("email"), req.get("password"));
		return res;
		//return Response.status(200).entity(res).build();
	}
}

