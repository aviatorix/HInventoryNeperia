package com.neperiagroup.controllerApiJersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.QuantityUser;

@Path("amount")	
public class GetQuantityUsers extends QuantityUser{
	@GET
	@Path("us")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get() throws JSONException {
		JSONObject res = null;
		res = QueryQuantityUser();
		return res;
	}
}
