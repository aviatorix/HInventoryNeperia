package com.neperiagroup.controllerApiJersey;

import java.lang.annotation.Annotation;

//import java.security.Security;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
//import com.mysql.jdbc.Security;
import com.neperiagroup.connectDB.*;
import com.neperiagroup.connectDB.Authentication.Security;


@Path("show")
public class GetShowDB extends ShowDB {
	@GET
	@Path("users")
	@Security
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get(@QueryParam("token") String token) throws InstantiationException, IllegalAccessException {
		JSONObject res = null;
		if (token != null) {
			
			System.out.println("sono qui! "+token);
			//Security sec = Security.class.newInstance();
			
			//sec.annotationType();
			
			try {
				res = ShowDB.QueryShowDB();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return res;
			//return Response.status(200).entity(res).build();
		}
		return null;
	}
}
