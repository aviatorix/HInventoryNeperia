package com.neperiagroup.controllerApiJersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.Authentication;


@Path("getMe")
public class GetMe extends Authentication {
	private JSONObject returnJSONObj = new JSONObject();

	@GET
	@Path("user")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get (@QueryParam("token") String token) {
		System.out.println("token: "+token);
		int resID = TokenVerify(token);
		System.out.println("resID: "+resID);

		try {
			returnJSONObj.put("IDuser", resID);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

		return returnJSONObj;

	}
}
