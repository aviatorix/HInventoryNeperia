package com.neperiagroup.controllerUpdateDevice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.updateDeviceModel.ShowDevices;

@Path("see")
public class GetDevices extends ShowDevices  {
	@GET
	@Path("devices")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get() {
		JSONObject res = null;
		
		try {
			res = ShowDevices.QueryShowDevices();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}



}
