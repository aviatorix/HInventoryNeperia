package com.neperiagroup.controllerUpdateDevice;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.updateDeviceModel.ShowSingleDevice;

@Path("give")
public class GetSingleDevice extends ShowSingleDevice{
	@GET
	@Path("device/{idre}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get(@PathParam("idre") int idre) {
		//return ShowDB.QueryShowDB();
		JSONObject res = null;
		try {
			System.out.println("idre: "+idre);
			res = ShowSingleDevice.QueryShowSingleDevice(idre);
		} catch (JSONException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(res);
		return res;
		//return Response.status(200).entity(res).build();
	}
}
