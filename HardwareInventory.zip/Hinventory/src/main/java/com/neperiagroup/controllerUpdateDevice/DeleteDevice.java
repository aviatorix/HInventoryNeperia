package com.neperiagroup.controllerUpdateDevice;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.updateDeviceModel.RemoveDevice;

@Path("canc")
public class DeleteDevice extends RemoveDevice {
	@DELETE
	@Path("device/{idre}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject canc(@PathParam("idre") int idre, JSONObject req) throws Exception {
		
		if (req.getString("email").length() == 0 || req.getString("password").length() == 0) {
			JSONObject res = RemoveDevice.QueryRemoveDevice(null, null, null);
			return res;
		}
		
		System.out.println("DeleteDevice");
		JSONObject res = RemoveDevice.QueryRemoveDevice(idre, req.get("email"), req.get("password"));
		return res;
	}
}
