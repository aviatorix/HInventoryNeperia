package com.neperiagroup.controllerUpdateDevice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;


import com.neperiagroup.updateDeviceModel.QuantityDevice;

@Path("quant")	
public class GetQuantityDevice extends QuantityDevice {
	@GET
	@Path("dev")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get() throws JSONException {
		JSONObject res = null;
		res = QueryQuantityDevice();
		return res;
	}
}
