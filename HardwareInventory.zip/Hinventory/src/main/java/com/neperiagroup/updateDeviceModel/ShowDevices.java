package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.MySingleton;

public class ShowDevices {
	
	protected static JSONObject QueryShowDevices() throws JSONException {
		System.out.println("QueryShowDevices");
		
		JSONArray risArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		JSONObject res = new JSONObject();
		
		MySingleton start = MySingleton.getInstance();
		String sql = "SELECT * FROM `device`";
		ResultSet rs = start.executeQuery(sql);
		
		try {
			while (rs.next() == true) {
				res = new JSONObject();
				res.put("name", rs.getString("name"));
				res.put("brand", rs.getString("brand"));
				res.put("model", rs.getString("model"));
			
				res.put("available", rs.getString("available"));
				res.put("date_insertion", rs.getString("dateOfIn"));
				res.put("ID_device", rs.getString("idre"));
				res.toString();
				risArray.put(res);
				System.out.println(res);
			}
		
			mainObj.put("Devices", risArray);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return mainObj;
	}
}
