package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.MySingleton;

public class GetDataBase {
	
	protected static JSONObject QueryShoWDataBase () {
		JSONArray risArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		JSONObject res = new JSONObject();
		
		MySingleton start = MySingleton.getInstance();
		String sql = "SELECT * FROM `device_user`";
		ResultSet rs = start.executeQuery(sql);
			
		try {
			while (rs.next() == true) {
				res = new JSONObject();
				res.put("ID_resource", rs.getInt("idre"));
				res.put("ID_user", rs.getString("idus"));
				res.put("Date_assignment", rs.getString("dateAssignment"));
				res.put("Model_device", rs.getString("modelDevice"));
				res.toString();
				risArray.put(res);
				System.out.println(risArray);
			}
		
			mainObj.put("Devices-Users", risArray);
			
		} catch (SQLException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mainObj;
	}
}
