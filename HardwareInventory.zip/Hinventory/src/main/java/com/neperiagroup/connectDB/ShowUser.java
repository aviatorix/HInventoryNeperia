package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class ShowUser  {
	
	protected static  JSONObject QueryShowUser(Object object) throws JSONException, SQLException {
		
		JSONObject res = new JSONObject();
		ResultSet rsIdus;
		
		MySingleton start = MySingleton.getInstance();
		System.out.println("object: "+object);
		// controllo esisestanza ID
		String idus = "SELECT idus FROM `users` WHERE idus='"+object+"'";
		rsIdus = start.executeQuery(idus);
		
		int count = 0;
		while (rsIdus.next()) {
			count++;
		}
		if (count == 0)	 {
			res.put("message","the ID doesn't exist");
			return res;
		}
		String sql = "SELECT name, surname, idus, regDate FROM `users` WHERE idus='"+object+"'";
		ResultSet rs = start.executeQuery(sql);
		
		try {
			while (rs.next() == true) {
				res = new JSONObject();
				res.put("name", rs.getString("name"));
				res.put("surname", rs.getString("surname"));
				res.put("IDUser", rs.getInt("idus"));
				res.put("Date_Of_Registation", rs.getDate("regDate"));
				System.out.println(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
}

