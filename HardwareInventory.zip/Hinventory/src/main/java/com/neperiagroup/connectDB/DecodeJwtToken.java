package com.neperiagroup.connectDB;

import com.sun.jersey.core.util.Base64;

public class DecodeJwtToken {

	private static String stringArrays[];
	private static String id;
	private static int convtoNumberID;
	@SuppressWarnings("static-access")
	protected  static int  DecodeJWT(String jwtToken){

		System.out.println("jwtToken: "+jwtToken);

		String[] split_string = jwtToken.split("\\.");
		String base64EncodedBody = split_string[1];

		Base64 base64Url = new Base64();
		String body = new String(base64Url.decode(base64EncodedBody));

		String[] res = body.split(",");
		String iss = res[2];
		String[] resIss = iss.split("");

		stringArrays = new String[resIss.length];

		//svuoto il contenuto 'id'
		String emptyID = ""; 
		id = emptyID;
		
		for (int i=0; i<resIss.length; i++) {
			stringArrays[i] = resIss[i];
		}
		
		for (int i=0; i<stringArrays.length; i++) {
			if (stringArrays[i].matches("[$&+,:;=?@#|'<>.-^*()%!]")) {
				if (stringArrays[i] != null) {
					id += stringArrays[i];
				}
			}
		}
		String[] idus = id.split(":");
		String resId = idus[1];

		try{
			convtoNumberID = Integer.parseInt(resId);
			System.out.println("DecodeJwt: "+convtoNumberID);
			return convtoNumberID;

		}catch(NumberFormatException ex){ // handle your exception
			System.out.println ("La stringa NON contiene un intero valido");
			ex.printStackTrace();
		}

		return convtoNumberID;
	}

}



