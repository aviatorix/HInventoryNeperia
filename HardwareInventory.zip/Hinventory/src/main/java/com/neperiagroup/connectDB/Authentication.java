package com.neperiagroup.connectDB;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


public class  Authentication extends DecodeJwtToken  {
	
	@Security
	protected static  int  TokenVerify(String token) {
		int tok = DecodeJWT(token);
		System.out.println("tokID: "+tok);
		return tok;
	}
	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.METHOD)
	public @interface Security {
		
	}

}


