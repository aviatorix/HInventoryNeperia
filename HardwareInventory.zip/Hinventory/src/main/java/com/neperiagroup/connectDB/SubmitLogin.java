package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.Statement;
import org.codehaus.jettison.json.JSONObject;

public class SubmitLogin extends CryptPassword {


	protected static JSONObject SubmitActionPerformed(Object object, Object object2 ) {
		// Create new instance of connection
		JSONObject res;
		res = new JSONObject();
		ResultSet resPass;
		ResultSet resEmail;
		String password;
		String idus = "";
		MySingleton start = MySingleton.getInstance();

		try {
			// dichiaro una nuova connessione
			//start.createConnection().createStatement();

			// controllo email 

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int count = 0;
			while (resEmail.next()) {
				count = +1;
			}
			if (count==0) {
				System.out.println("email doesnt't exist!");
				res.put("message", "email doesnt't exist!");
				res.toString(); 
				return res;
			}


			// password user(jsonObject to String);
			String jsonInString = (String) object2;
			System.out.println("jsonInString: "+jsonInString);

			// controllo password;

			String ctrlPass = "SELECT email, password FROM `users` WHERE email = '"+object+"'";
			Statement ctrLpassPrepared =  start.createConnection().prepareStatement(ctrlPass);
			resPass = ctrLpassPrepared.executeQuery(ctrlPass);

			while(resPass.next()){
				//Retrieve by column name
				String email  = resPass.getString("email");
				System.out.println("email: "+email);
				password  = resPass.getString("password");
				System.out.println("password: "+password);

				//-----------------
				//CryptPassword.checkPass(jsonInString, resPass.getString("password"));
				String CkPass = CryptPassword.checkPass(jsonInString, resPass.getString("password"));
				//auth password

				System.out.println("CkPass: "+CkPass);
				// Create new SQL Query
				String sql = "SELECT idus, name FROM `users` WHERE email='"+object+"' and password='"+CkPass+"'";
				ResultSet rs = start.executeQuery(sql);

				count = 0;
				while (rs.next()) {
					count = +1;
					idus =""+rs.getInt("idus");
					System.out.println("idus: "+idus);
				}
				if (count == 1) {
					System.out.println("User Found, Access Granted!");
					String token = JwtToken.jwTWithRsa(idus, object2);
					res.put("message", "User Found, Access Granted!");
					res.put("token", token);
					res.toString(); 
				}

				else if (count == 0) {
					System.out.println(count);
					System.out.println("Error, Access Denied!");
					res.put("message", "Error, Access Denied!");
					res.toString(); 

				}

			}


		}catch (Exception ex) {
			System.out.println("Syntax error");
			ex.printStackTrace();
		}

		return res;
	}

}
