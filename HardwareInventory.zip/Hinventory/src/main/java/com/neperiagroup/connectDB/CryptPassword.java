package com.neperiagroup.connectDB;

import org.mindrot.jbcrypt.BCrypt;

public class CryptPassword {

	protected static String hashPassword(String plainTextPassword){
		return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
	}


	protected static String checkPass(String plainPassword, String hashedPassword) {
		if (BCrypt.checkpw(plainPassword, hashedPassword)) {
			System.out.println("The password matches.");
			System.out.println(hashedPassword);
			return hashedPassword;
		} else {
			System.out.println("The password does not match.");
			return "The password does not match.";
		}
	}

	/*public static void main (String a[]) {
			System.out.println(hashPassword("1234"));
			checkPass("1234", "$2a$10$8AwqEm5H6FPnKarEDK.mP.VZpjLlqGg67kjgMX02FEHxgRkUUEqNi");
	}*/
}
