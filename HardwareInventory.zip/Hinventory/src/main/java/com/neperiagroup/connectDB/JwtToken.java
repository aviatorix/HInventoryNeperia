package com.neperiagroup.connectDB;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import io.jsonwebtoken.*;
import java.util.Date;   

public class JwtToken {


	public static String jwTWithRsa(String string, Object object2) throws NoSuchAlgorithmException {

		KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA");
		keyGenerator.initialize(1024);
		KeyPair kp = keyGenerator.genKeyPair();

		PrivateKey privateKey = (PrivateKey) kp.getPrivate();

		String token = generateJwtToken(privateKey, string, object2);
		System.out.println(token);
		return token;

	}

	protected static String generateJwtToken(PrivateKey privateKey, String object, Object object2) {

		String token = Jwts.builder().setSubject((String) object2)
				.setExpiration(new Date())
				.setIssuer( object)
				//.claim("groups", new String[] { "user", "admin" })
				// RS256 with privateKey
				.signWith(SignatureAlgorithm.RS256, privateKey).compact();

		return token;
	}

}
