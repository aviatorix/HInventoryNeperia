package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.codehaus.jettison.json.JSONObject;


import com.neperiagroup.connectDB.MySingleton;

public class Registration extends CryptPassword {

	protected static  JSONObject RegAction(Object object, Object object2, Object object3, Object object4) {
		
		// Declaration var & object
		JSONObject res;
		res = new JSONObject();
		ResultSet resEmail;
		// Create new instance of connection
		MySingleton start = MySingleton.getInstance();

		try {
			
			//controllo sui parametri in ingresso (non possono essere vuoti).			
			if (object == null || object2 == null || object3 == null || object4 == null ) {
				res.put("message", "You can't leave empty fields");
				return res;
			}
			
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();

			// controllo email esce se ne trova..

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object4+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int count = 0;
			while (resEmail.next()) {
				count = +1;
			}
			if (count==1) {
				System.out.println("email already in use!");
				res.put("message", "email already in use");
				res.toString(); 
				return res;
			}

			//-----------------
			else {
				
				//"UPDATE `device` SET
				// password user(jsonObject to String);
				String jsonInString = (String) object3;
			
				String sql = "INSERT INTO `users` (name, surname, password, email, regDate) VALUES ('"+object+"', '"+object2+"', '"+CryptPassword.hashPassword(jsonInString)+"', '"+object4+"', '"+dateFormat.format(cal.getTime())+"')";
				
				Statement prepared =  start.createConnection().prepareStatement(sql);

				prepared.executeUpdate(sql);

				String sql2 = "SELECT * FROM `users`";
				ResultSet rs = start.executeQuery(sql2);

				while (rs.next()) {
					System.out.println(rs.getString("name")+" "+rs.getString("surname")+" "+rs.getString("password")+" "+rs.getString("email"));
					res.put("name", rs.getString("name"));
					res.put("surname", rs.getString("surname"));
					res.put("password", rs.getString("password"));
					res.put("email", rs.getString("email"));
					res.toString(); 	
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 

		return res;

	}

}
