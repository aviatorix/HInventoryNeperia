package com.neperiagroup.connectDB;

import java.sql.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class MySingleton {
	static final String url = "jdbc:mysql://localhost:3306/";
	static final String dbName = "corporate_resources";
	static final String driver = "com.mysql.jdbc.Driver";
	static final String userName = "root";

	
	private static MySingleton myObj;
	private  Connection Con;
	
	private MySingleton() {
		System.out.println("Connection Database start");
		Con = createConnection();
	}
	
	@SuppressWarnings("rawtypes")
	public Connection createConnection() {
		Connection connection = null;
	
		try {
			// Load the JDBC driver
			Class driver_class = Class.forName(driver);
			Driver driver = (Driver) driver_class.newInstance();
			DriverManager.registerDriver(driver);
			connection = DriverManager.getConnection(url + dbName + "?user="+ userName);
			
		
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (IllegalAccessException ex) {
			ex.printStackTrace();
		} catch (InstantiationException ex) {
			ex.printStackTrace();
		}
		return connection;
	}
	
	/*
	 * Create a static method to get instance.
	 */
	public static MySingleton getInstance() {
		if (myObj == null) {
			myObj = new MySingleton();
		}
		return myObj;
	}
	

	public ResultSet executeQuery(String sql) {
		
		System.out.println(sql);
		ResultSet res;
		try {
			Statement statement = Con.createStatement();
			res = statement.executeQuery(sql);
			
			return res;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return null;
				
	}
}	








