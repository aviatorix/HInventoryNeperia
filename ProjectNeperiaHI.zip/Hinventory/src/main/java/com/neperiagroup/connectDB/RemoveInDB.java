package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.codehaus.jettison.json.JSONObject;


public class RemoveInDB {

	protected static JSONObject QueryRemoveInDB(Object object, Object object2, Object object3) {

		ResultSet resId;
		JSONObject res;
		res = new JSONObject();
		ResultSet resAdmin;
		ResultSet resPass;
		String password;
		ResultSet resEmail;

		MySingleton start = MySingleton.getInstance();

		try {

			// controllo email 

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object2+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int cnt = 0;
			while (resEmail.next()) {
				cnt = +1;
			}
			if (cnt==0) {
				System.out.println("email doesnt't exist!");
				res.put("message", "email doesnt't exist!");
				res.toString(); 
				return res;
			}

			// password user(jsonObject to String);
			String jsonInString = (String) object3;
			System.out.println("jsonInString: "+jsonInString);

			// controllo password;
			String ctrlPass = "SELECT email, password FROM `users` WHERE email = '"+object2+"'";
			Statement ctrLpassPrepared =  start.createConnection().prepareStatement(ctrlPass);
			resPass = ctrLpassPrepared.executeQuery(ctrlPass);

			while(resPass.next()){

				password  = resPass.getString("password");
				String CkPass = CryptPassword.checkPass(jsonInString, password);
				//auth password

				// Gestione Administrator true or false
				String isAdmin = "SELECT admin FROM `users` WHERE admin=true AND email='"+object2+"'AND password='"+CkPass+"'";
				Statement ctrlAdmin =  start.createConnection().prepareStatement(isAdmin);
				resAdmin = ctrlAdmin.executeQuery(isAdmin);

				int counter = 0;
				while (resAdmin.next()) {
					counter = +1;
				}
				if (counter==1) {

					String sql2 = "SELECT idus FROM `users` WHERE idus='"+object+"'";
					Statement prepared2 = start.createConnection().prepareStatement(sql2);
					resId = prepared2.executeQuery(sql2);

					int count = 0;
					while (resId.next()) {

						count = +1;
						String sql = "DELETE FROM `users` WHERE idus='"+object+"'";
						Statement prepared = start.createConnection().prepareStatement(sql);
						prepared.execute(sql);
						System.out.println("Deleted successfully!");
						res.put("message", "Deleted successfully!");
						res.toString();
					}
					if (count==0) {
						System.out.println("ID dosen't exist!");
						res.put("message", "ID dosen't exist!");
						res.toString(); 
						return res;
					}
				}
				else if (counter==0) {
					res.put("message", "Sorry, You don't have administrator permissions");
					res.toString(); 
				}

			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 
		return res;
	}

}
