package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.codehaus.jettison.json.JSONObject;

public class RegAdmin  {
	
protected static  JSONObject RegAction(Object object, Object object2, Object object3, Object object4) {
		
		// Declaration var & object
		JSONObject res;
		res = new JSONObject();
		ResultSet resEmail;
		ResultSet resAdmin;
		// Create new instance of connection
		MySingleton start = MySingleton.getInstance();

		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();

			// controllo email esce se ne trova..

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object4+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int count = 0;
			while (resEmail.next()) {
				count = +1;
			}
			if (count==1) {
				System.out.println("email already in use!");
				res.put("message", "email already in use");
				res.toString(); 
				return res;
			}

			//-----------------
			else {
				
				// Gestione Administrator true or false
				String isAdmin = "SELECT admin FROM `users` WHERE admin=true";
				Statement ctrlAdmin =  start.createConnection().prepareStatement(isAdmin);
				resAdmin = ctrlAdmin.executeQuery(isAdmin);
				
				count = 0;
				while (resAdmin.next()) {
					count = +1;
				}
				if (count==1) {
					System.out.println("Admin already present, there can only be one admin");
					res.put("message", "Admin already present, there can only be one admin");
					res.toString(); 
					return res;
				}
				
				//"UPDATE `device` SET
				// password user(jsonObject to String);
				String jsonInString = (String) object3;
			
				String sql = "INSERT INTO `users` (name, surname, password, email, regDate, admin) VALUES ('"+object+"', '"+object2+"', '"+CryptPassword.hashPassword(jsonInString)+"', '"+object4+"', '"+dateFormat.format(cal.getTime())+"', true)";
				
				Statement prepared =  start.createConnection().prepareStatement(sql);

				prepared.executeUpdate(sql);

				String sql2 = "SELECT * FROM `users`";
				ResultSet rs = start.executeQuery(sql2);

				while (rs.next()) {
					System.out.println(rs.getString("name")+" "+rs.getString("surname")+" "+rs.getString("password")+" "+rs.getString("email"));
					res.put("name", rs.getString("name"));
					res.put("surname", rs.getString("surname"));
					res.put("password", rs.getString("password"));
					res.put("email", rs.getString("email"));
					res.toString(); 	
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 

		return res;

	}
	
	
}
