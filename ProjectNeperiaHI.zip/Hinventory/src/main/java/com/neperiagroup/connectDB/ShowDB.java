package com.neperiagroup.connectDB;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class ShowDB {
	
	protected static  JSONObject QueryShowDB() throws JSONException {
		
		System.out.println("QueryShowDB");
		
		JSONArray risArray = new JSONArray();
		JSONObject mainObj = new JSONObject();
		JSONObject res = new JSONObject();
			
		MySingleton start = MySingleton.getInstance();
		String sql = "SELECT * FROM `users`";
		ResultSet rs = start.executeQuery(sql);
		
		try {
			
			while (rs.next() == true) {
				res = new JSONObject();
				res.put("name", rs.getString("name"));
				res.put("IDUser", rs.getInt("idus"));
				res.put("Date", rs.getDate("regDate"));
				res.toString();
				risArray.put(res);
				System.out.println(res);
			}
	
			
			mainObj.put("Users", risArray);
			
		} catch (SQLException e) {
				e.printStackTrace();
			//return res.put("message", "SQLException");
		}
		
		return mainObj;
	}

}
