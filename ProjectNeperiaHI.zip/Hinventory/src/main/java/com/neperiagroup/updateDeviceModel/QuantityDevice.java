package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.MySingleton;

public class QuantityDevice {
	
	protected JSONObject QueryQuantityDevice() throws JSONException {
		JSONObject res = new JSONObject();
		
		MySingleton start = MySingleton.getInstance();
		String sql = "SELECT * FROM `device`";
		ResultSet rs = start.executeQuery(sql);
		
		try {
			int count = 0;
			while (rs.next() == true) {
				res = new JSONObject();
				count++;
				System.out.println("count: "+count);
			}
			
			res.put("Total amount of devices", count);
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res.put("Total amount of devices", 0);
		}
		
		return res;
	}
}
