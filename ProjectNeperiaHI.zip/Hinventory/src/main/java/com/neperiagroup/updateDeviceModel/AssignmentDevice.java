package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.CryptPassword;
import com.neperiagroup.connectDB.MySingleton;

public class AssignmentDevice extends CryptPassword{

	protected static JSONObject QueryAssignmentDevice (Object object, Object object2, Object object3, Object object4){
		JSONObject res;
		res = new JSONObject();
		ResultSet rsAvailable;
		ResultSet rs;
		ResultSet resPass;
		String password;
		ResultSet resAdmin;
		ResultSet resEmail;

		MySingleton start = MySingleton.getInstance();

		try {

			// SELECT * FROM device JOIN device_user ON device.idre = device_user.idre WHERE available=true
			// INSERT INTO device_user (idus, idre, dateAssignment, modelDevice) VALUES (25, 13," 2018-08-01","B5")
			// CREATE TABLE device_user(idre int, idus int, dateAssignment date DEFAULT null, modelDevice varchar(50));
			// SELECT * FROM device JOIN device_user ON available=true
			// SELECT COUNT(*) FROM device JOIN device_user ON available=true GROUP BY name

			//controllo sui parametri in ingresso (non possono essere vuoti).			
			if (object == null || object2 == null || object3 == null || object4 == null) {
				res.put("message", "You can't leave empty fields");
				return res;
			}
			
			// controllo email 
			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object3+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int cnt = 0;
			while (resEmail.next()) {
				cnt = +1;
			}
			if (cnt==0) {
				System.out.println("email doesnt't exist!");
				res.put("message", "email doesnt't exist!");
				res.toString(); 
				return res;
			}

			String jsonInString = (String) object4;
			String ctrlPass = "SELECT email, password FROM `users` WHERE email = '"+object3+"'";
			Statement ctrLpassPrepared =  start.createConnection().prepareStatement(ctrlPass);
			resPass = ctrLpassPrepared.executeQuery(ctrlPass);

			while(resPass.next()){

				password  = resPass.getString("password");
				String CkPass = CryptPassword.checkPass(jsonInString, password);

				// Controllo Administrator true or false
				String isAdmin = "SELECT admin FROM `users` WHERE admin=true AND email='"+object3+"'AND password='"+CkPass+"'";
				Statement ctrlAdmin =  start.createConnection().prepareStatement(isAdmin);
				resAdmin = ctrlAdmin.executeQuery(isAdmin);

				int counter = 0;
				while (resAdmin.next()) {
					counter = +1;
				}
				if (counter==1) {

					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
					Calendar cal = Calendar.getInstance();

					String sql = "SELECT * FROM `device` WHERE available= true AND name='"+object+"'";
					Statement prepared;
					prepared = start.createConnection().prepareStatement(sql);
					rsAvailable = prepared.executeQuery(sql);

					int count = 0;
					while (rsAvailable.next()) {
						//Modify table users
						count++;

						int idre = rsAvailable.getInt("idre");
						System.out.println("idre: "+idre);
						String modelDevice = rsAvailable.getString("model");
						res.put("IDresource", rsAvailable.getInt("idre"));

						//controllo esistenza utente
						String tryIdus = "SELECT idus FROM `users` WHERE email='"+object2+"'";
						Statement prepared3 =  start.createConnection().prepareStatement(tryIdus);
						rs = prepared3.executeQuery(tryIdus);

						int idus = 0;
						int meter = 0;
						while (rs.next()) {
							meter++;
							idus = rs.getInt("idus");
							System.out.println("idus: "+idus);
						}
						if (meter == 0) {
							res.put("message", "no user found");
							return res;
						}


						// String update = "UPDATE `users` SET idre='"+idre+"', dateOfAssign='"+dateFormat.format(cal.getTime())+"' WHERE email='"+object2+"'";
						String sql2 = "INSERT INTO `device_user` (idre, idus, dateAssignment, modelDevice) VALUES ('"+idre+"', '"+idus+"','"+dateFormat.format(cal.getTime())+"', '"+modelDevice+"')";
						Statement prepared2 =  start.createConnection().prepareStatement(sql2);
						prepared2.executeUpdate(sql2);

						String sql3 = "UPDATE `device` SET available=false WHERE idre='"+idre+"'";
						Statement prepared4 =  start.createConnection().prepareStatement(sql3);
						prepared4.executeUpdate(sql3);
						
						int add=1;
						String sql4 = "UPDATE `users` SET quantityHeld=quantityHeld+'"+add+"' WHERE idus='"+idus+"'";
						Statement prepared5 =  start.createConnection().prepareStatement(sql4);
						prepared5.executeUpdate(sql4);

						res.put("message", "resource successfully assigned");

					}

					if (count == 0) {
						res.put("message", "no device available");
						return res;
					}
				}	
				else if (counter==0) {
					res.put("message", "Sorry, You don't have administrator permissions");
					res.toString(); 
				}
			}

		} catch (SQLException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
}
