package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.CryptPassword;
import com.neperiagroup.connectDB.MySingleton;

public class InsertionDevice extends CryptPassword {

	protected static JSONObject UpdateDevice(Object object, Object object2, Object object3, Object object4, Object object5) {

		// Declaration var & object
		JSONObject res;
		res = new JSONObject();
		ResultSet resModelBrand ;
		ResultSet resPass;
		String password;
		ResultSet resAdmin;
		ResultSet resEmail;

		// new instance of connection
		MySingleton start = MySingleton.getInstance();

		try {
			//controllo sui parametri in ingresso (non possono essere vuoti).			
			if (object == null || object2 == null || object3 == null || object4 == null || object5 == null) {
				res.put("message", "You can't leave empty fields");
				return res;
			}


			// controllo email 

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object4+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int cnt = 0;
			while (resEmail.next()) {
				cnt = +1;
			}
			if (cnt==0) {
				System.out.println("email doesnt't exist!");
				res.put("message", "email doesnt't exist!");
				res.toString(); 
				return res;
			}

			String jsonInString = (String) object5;
			String ctrlPass = "SELECT email, password FROM `users` WHERE email = '"+object4+"'";
			Statement ctrLpassPrepared =  start.createConnection().prepareStatement(ctrlPass);
			resPass = ctrLpassPrepared.executeQuery(ctrlPass);

			while(resPass.next()){

				password  = resPass.getString("password");
				String CkPass = CryptPassword.checkPass(jsonInString, password);

				// Controllo Administrator true or false
				String isAdmin = "SELECT admin FROM `users` WHERE admin=true AND email='"+object4+"'AND password='"+CkPass+"'";
				Statement ctrlAdmin =  start.createConnection().prepareStatement(isAdmin);
				resAdmin = ctrlAdmin.executeQuery(isAdmin);

				int counter = 0;
				while (resAdmin.next()) {
					counter = +1;
				}
				if (counter==1) {

					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
					Calendar cal = Calendar.getInstance();

					//controllo del modello e brand

					String modelBrand = "SELECT idre, name FROM `device` WHERE brand='"+object2+"'and model='"+object3+"'";

					Statement ctrl =  start.createConnection().prepareStatement(modelBrand);
					resModelBrand = ctrl.executeQuery(modelBrand);

					int count = 0;
					while (resModelBrand.next()) {
						count++;
					}
					if (count == 1) {
						res.put("message", "Device already present!");
						return res;
					}

					String sql = "INSERT INTO `device` (name, brand, model, dateOfIn) VALUES ('"+object+"', '"+object2+"', '"+object3+"', '"+dateFormat.format(cal.getTime())+"')";
					Statement prepared;
					prepared = start.createConnection().prepareStatement(sql);
					prepared.executeUpdate(sql);
					res.put("message", "Device successfully inserted!");

				}
				else if (counter==0) {
					res.put("message", "Sorry, You don't have administrator permissions");
					res.toString(); 
				}

			} 
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 

		return res;
	}	

}
