package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.CryptPassword;
import com.neperiagroup.connectDB.MySingleton;

public class RemoveDevice extends CryptPassword {

	protected static JSONObject QueryRemoveDevice(Object object, Object object2, Object object3) {
		ResultSet resId;
		JSONObject res;
		res = new JSONObject();
		ResultSet resPass;
		String password;
		ResultSet resAdmin;
		ResultSet resEmail;
		
		MySingleton start = MySingleton.getInstance();

		System.out.println("RemoveDevice");

		try {
			
			//controllo sui parametri in ingresso (non possono essere vuoti).			
			if (object == null || object2 == null || object3 == null) {
				res.put("message", "You can't leave empty fields");
				return res;
			}
			
			// controllo email 

			String ctrlEmail = "SELECT email FROM `users` WHERE email = '"+object2+"'";
			Statement ctrLprepared =  start.createConnection().prepareStatement(ctrlEmail);
			resEmail = ctrLprepared.executeQuery(ctrlEmail);

			int cnt = 0;
			while (resEmail.next()) {
				cnt = +1;
			}
			if (cnt==0) {
				System.out.println("email doesnt't exist!");
				res.put("message", "email doesnt't exist!");
				res.toString(); 
				return res;
			}


			System.out.println("controllo se sei admin");
			String jsonInString = (String) object3;
			System.out.println("jsonInString "+jsonInString);
			String ctrlPass = "SELECT email, password FROM `users` WHERE email = '"+object2+"'";
			Statement ctrLpassPrepared =  start.createConnection().prepareStatement(ctrlPass);
			resPass = ctrLpassPrepared.executeQuery(ctrlPass);

			while(resPass.next()){

				//auth password

				password  = resPass.getString("password");
				String CkPass = CryptPassword.checkPass(jsonInString, password);
				
				// Controllo Administrator true or false
				String isAdmin = "SELECT admin FROM `users` WHERE admin=true AND email='"+object2+"'AND password='"+CkPass+"'";
				Statement ctrlAdmin =  start.createConnection().prepareStatement(isAdmin);
				resAdmin = ctrlAdmin.executeQuery(isAdmin);

				//Todo control Admin

				int counter = 0;
				while (resAdmin.next()) {
					counter = +1;
				}
				if (counter==1) {

					String sql2 = "SELECT idre FROM `device` WHERE idre='"+object+"'";
					Statement prepared2;
					prepared2 = start.createConnection().prepareStatement(sql2);
					resId = prepared2.executeQuery(sql2);

					int count = 0;
					while (resId.next()) {
						count = +1;
						String sql = "DELETE FROM `device` WHERE idre='"+object+"'";
						Statement prepared = start.createConnection().prepareStatement(sql);
						prepared.execute(sql);
						System.out.println("Deleted successfully!");
											
						String device_users = "DELETE FROM `device_user` WHERE idre='"+object+"'"; 
						Statement prepared3 = start.createConnection().prepareStatement(device_users);
						prepared3.execute(device_users);
						
						res.put("message", "Deleted successfully!");
						res.toString();
					}
					if (count==0) {
						System.out.println("ID dosen't exist!");
						res.put("message", "ID dosen't exist!");
						res.toString(); 
						return res;
					}
				}
				else if (counter==0) {
					res.put("message", "Sorry, You don't have administrator permissions");
					res.toString(); 
				}

			}

		} catch (SQLException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return res;
	}

}
