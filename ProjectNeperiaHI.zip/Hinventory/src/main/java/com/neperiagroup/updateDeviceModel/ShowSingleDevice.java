package com.neperiagroup.updateDeviceModel;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.MySingleton;

public class ShowSingleDevice {
	
	protected static JSONObject QueryShowSingleDevice(Object object) throws JSONException, SQLException {
		JSONObject res = new JSONObject();
		ResultSet rsIdre;
		
		MySingleton start = MySingleton.getInstance();
		String idre = "SELECT idre FROM `device` WHERE idre='"+object+"'";
		rsIdre = start.executeQuery(idre);
		
		int count = 0;
		while (rsIdre.next()) {
			count++;
		}
		if (count == 0)	 {
			res.put("message","the ID doesn't exist");
			return res;
		}
		
		String sql = "SELECT name, brand, model, available, dateOfIn, idre FROM `device` WHERE idre='"+object+"'";
		ResultSet rs = start.executeQuery(sql);
		
		while (rs.next() == true) {
			res = new JSONObject();
			res.put("name", rs.getString("name"));
			res.put("brand", rs.getString("brand"));
			res.put("model", rs.getString("model"));
			res.put("available", rs.getBoolean("available"));
			res.put("date_of_insertion", rs.getDate("dateOfIn"));
			res.put("ID_resource", rs.getInt("idre"));
		}
		
		return res;
	}
}
