package com.neperiagroup.controllerApiJersey;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;


import com.neperiagroup.connectDB.ShowUser;

@Path("get")
public class GetUser extends ShowUser {
	@GET
	@Path("user/{idus}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get(@PathParam("idus") int idus) {
		//return ShowDB.QueryShowDB();
		JSONObject res = null;
		try {
			System.out.println("idus: "+idus);
			res = ShowUser.QueryShowUser(idus);
		} catch (JSONException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(res);
		return res;
		//return Response.status(200).entity(res).build();
	}


}