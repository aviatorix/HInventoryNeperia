package com.neperiagroup.controllerApiJersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.*;


@Path("show")
public class GetShowDB extends ShowDB {
	@GET
	@Path("users")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject get() {
		//return ShowDB.QueryShowDB();
		JSONObject res = null;
		try {
			res = ShowDB.QueryShowDB();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
		//return Response.status(200).entity(res).build();
	}

}
