package com.neperiagroup.controllerApiJersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.neperiagroup.connectDB.RegAdmin;

@Path("add")
public class RegAdministrator extends RegAdmin {

	@POST
	@Path("admin")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject post(JSONObject req) throws JSONException {

		System.out.println("req: "+req);
		JSONObject res = RegAdmin.RegAction(req.get("name"), req.get("surname"), req.get("password"), req.get("email"));
		return res;
	}

}