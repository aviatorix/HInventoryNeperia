package com.neperiagroup.controllerUpdateDevice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.neperiagroup.updateDeviceModel.*;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;



@Path("in")
public class PostDevice extends InsertionDevice {
	@POST
	@Path("device")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	
	public JSONObject post(JSONObject req) throws JSONException {
		System.out.println("Post in Device");
		System.out.println("req: "+req);
		//System.out.println("model: "+req.isNull("model"));
		//System.out.println("model: "+req.getString("model") == "");
		System.out.println("model: "+req.getString("model").length());
		if (req.getString("name").length() == 0 || req.getString("brand").length() == 0|| req.getString("model").length() == 0 || req.getString("email").length() == 0 || req.getString("password").length() == 0) {
			JSONObject res = UpdateDevice(null, null, null, null, null);
			return res;
		}
		JSONObject res = UpdateDevice(req.get("name"), req.get("brand"), req.get("model"), req.get("email"), req.get("password") );
		return res;
	}
}
