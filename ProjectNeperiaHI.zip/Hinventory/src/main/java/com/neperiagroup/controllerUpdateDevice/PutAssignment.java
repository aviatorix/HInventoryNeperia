package com.neperiagroup.controllerUpdateDevice;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import com.neperiagroup.updateDeviceModel.AssignmentDevice;

@Path("ass")
public class PutAssignment extends AssignmentDevice {
	@PUT
	@Path("device")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public JSONObject put(JSONObject req) throws JSONException {
		if (req.getString("name_device").length() == 0 || req.getString("assigned_to").length() == 0|| req.getString("admin").length() == 0 || req.getString("password").length() == 0) {
			JSONObject res = AssignmentDevice.QueryAssignmentDevice(null, null, null, null);
			return res;
		}
		
		JSONObject res = AssignmentDevice.QueryAssignmentDevice(req.get("name_device"), req.get("assigned_to"), req.get("admin"), req.get("password"));
		return res;
	}
}
