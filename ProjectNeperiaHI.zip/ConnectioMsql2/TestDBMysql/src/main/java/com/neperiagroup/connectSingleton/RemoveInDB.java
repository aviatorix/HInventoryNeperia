package com.neperiagroup.connectSingleton;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class RemoveInDB {

	private static void QueryRemoveInDB() {
		
		MySingleton start = MySingleton.getInstance();
		
		try {
			
			String sql = "DELETE FROM `neperia` WHERE username='caio'";
			Statement prepared = start.createConnection().prepareStatement(sql);
			prepared.execute(sql);
			
			System.out.println("Deleted successfully!");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 
		
	}
	
	public static void main (String a[]) {
		QueryRemoveInDB();
	}

}
