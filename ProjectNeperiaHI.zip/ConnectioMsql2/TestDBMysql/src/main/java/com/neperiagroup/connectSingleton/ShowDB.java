package com.neperiagroup.connectSingleton;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ShowDB {
	
	public static  String QueryShowDB() {
	
		String res="";
		MySingleton start = MySingleton.getInstance();
		
		String sql = "SELECT * FROM `neperia`";
		ResultSet rs = start.executeQuery(sql);
		
		try {
			while (rs.next()) {
				System.out.println(rs.getString("username")+" "+rs.getString("password")+" "+rs.getInt("id"));
				res = rs.getString("username")+" "+rs.getString("password")+" "+rs.getInt("id");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "SQLException";
		}
		
		return res;
	}

	public static void main (String a[]) {
		QueryShowDB();
	}
}
