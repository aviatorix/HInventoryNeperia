package com.neperiagroup.connectSingleton;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import java.sql.Connection;
import java.sql.Statement;
import com.neperiagroup.connectSingleton.MySingleton;

public class SubmitLogin {
	static String uname = "";
	static String upass = "";
	
	private static void SubmitActionPerformed() {
		
		// Check Username and Password
		Scanner input = new Scanner(System.in);
		System.out.println("Enter username:");
		String uname = input.next();
		System.out.println("Enter password:");
		String upass = input.next();
		
		// Create new instance of connection
		MySingleton start = MySingleton.getInstance();
		
		try {
			// dichiaro una nuova connessione
			//start.createConnection().createStatement();
			// Create SQL Query
			String sql = "SELECT username, password FROM `neperia` WHERE username='"+uname+"' and password='"+upass+"'";
			ResultSet rs = start.executeQuery(sql);
			
			int count = 0;
			while (rs.next()) {
				count = +1;
			}
			if (count==1) {
				System.out.println("User Found, Access Granted!");
			}
			else if (count>1) {
				System.out.println("Duplicate, User, Access Denied!");
			} else {
				System.out.println("User doesnt't exist!");
			}
	
		}catch (Exception ex) {
			System.out.println("Errore di sintassi");
			ex.printStackTrace();
		}
		
		
	}
	
	public static void main(String a[])  {
		SubmitActionPerformed();
	}
}
