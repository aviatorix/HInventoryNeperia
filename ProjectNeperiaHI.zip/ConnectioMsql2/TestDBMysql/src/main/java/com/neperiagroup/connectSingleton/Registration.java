package com.neperiagroup.connectSingleton;

import com.neperiagroup.connectSingleton.MySingleton;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Registration {
	static String uname = "";
	static String upass = "";

	private static void RegAction() {
		// Insert username and Password
		/*Scanner input = new Scanner(System.in);
		System.out.println("Enter username:");
		String uname = input.next();
		System.out.println("Enter password:");
		String upass = input.next();*/
	
		// Create new instance of connection
		MySingleton start = MySingleton.getInstance();
		
		try {
			
			String sql = "INSERT INTO `neperia` (id , username, password) VALUES (5, 'caio', 'entra')";
			Statement prepared =  start.createConnection().prepareStatement(sql);
			/*prepared.setInt(1, 55);
			prepared.setString(2, "pippo");
			prepared.setString(3, "entra");*/
			
			prepared.executeUpdate(sql);
			
			String sql2 = "SELECT * FROM `neperia`";
			ResultSet rs = start.executeQuery(sql2);
			
			while (rs.next()) {
				System.out.println(rs.getString("username")+" "+rs.getString("password")+" "+rs.getInt("id"));
			}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} 
	}
	
	public static void main (String a[]) {
		RegAction();
	}
}
