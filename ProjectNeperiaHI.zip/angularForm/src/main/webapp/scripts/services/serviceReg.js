
var app = angular.module("myApp");

app.service('serviceReg',  [registrationService]);

registrationService.$inject = ['$scope', 'user', '$http'];

function registrationService ($scope, user, $http) {
	//validation form
	console.log("registrationService");
	
	function successAlert() {
		console.log("success()");
		$scope.alerts.push({msg: 'Well done! Your registration has been successful' });
	};

	function dangerAlert() {
		console.log("danger()");
		$scope.alertd.push({msg: 'Sorry! Email already in use!' });
	}

	function closeAlert() {
		console.log("closeAlert()");
		$scope.alerts.splice($scope.index, 1);
		$scope.alertd.splice($scope.index, 1);
	};

	if($scope.click === true) {
		updateService();
	}
	else 
		if ($scope.click === false) {
			reset();
		} 


	function updateService() {

		$http.post('http://localhost:8080/Hinventory/rest/reg/user', {
			name: user.name,
			surname: user.surname,
			email: user.email,
			password: user.password
		})
		.then((response) => {
			console.log("response", response);
			console.log("response.data.message:", response.data.message)

			if (response.data.message === "email already in use") {
				if ($scope.alertd.length < 2) {

					closeAlert();
					dangerAlert();
				}
			}
			else {
				if ($scope.alerts.length < 2) {

					closeAlert();	
					successAlert();
				}
			}

		})

	}


	function reset() {
		$scope.master = {};
		console.log("function: reset()");
		$scope.user = angular.copy($scope.master);
		closeAlert();
	}

	reset();
}