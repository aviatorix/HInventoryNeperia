'use strict';

var app = angular.module('myApp')
app.service('serviceLog',  [loginService]);

loginService.$inject = ['$scope', '$http', '$log', 'user'];

function loginService($scope, $http, user) {
	console.log("loginService");
	
	if ($scope.click == true) {login()}
	
	function login() {
		console.log("loginInService");
		console.log(user);
		$http.post('http://localhost:8080/Hinventory/rest/log/user', {
			email: user.email,
			password: user.password
		})
		.then((response) => {
			console.log("response", response);
			console.log("response.data.message:", response.data.message)

		})
	}
}
