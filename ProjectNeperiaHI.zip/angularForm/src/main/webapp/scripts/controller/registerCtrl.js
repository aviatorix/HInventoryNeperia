var app = angular.module("myApp")

app.controller('registerCtrl', [ '$scope', '$http', regCtrl,]);

regCtrl.$inject = ['serviceReg'];

function regCtrl($scope, $http) {
	console.log("registerController");
	$scope.update = update;
	$scope.reset = reset;
	$scope.closeMyAlert = closeMyAlert;
	
	user:  {
		name: ''
			surname: ''
				email: ''
					password: ''
	}
	$scope.alerts = [
		{ type: 'success', msg: '' },
		];

	$scope.alertd = [
		{type: 'danger', msg:''}
		]

	function update(user) {
		$scope.click= true;
		registrationService($scope, user, $http);
	}

	function reset() {
		console.log("$scope.click: "+$scope.click);
		$scope.click= false;
		registrationService($scope);
	}

	function closeMyAlert($index) {
		$scope.alertd.splice($index, 1)
		$scope.alerts.splice($index, 1)
	}

}