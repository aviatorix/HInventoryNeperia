'use strict';

var app = angular.module('myApp');
app.controller('loginCtrl', ['$scope', '$http', '$log', '$rootScope', logCtrl]);

logCtrl.$inject = ['serviceLog']; 

function logCtrl($scope, $http, $log, $rootScope) {
	console.log("loginController");
	$scope.login = login;

	$scope.msgTitle = 'Alert';
	$scope.msgBody  = 'The Tomatoes Exploded!';
	$scope.msgType  = 'warning';

	$scope.flash = flash;


	function login(user) {
		$scope.click = true;
		loginService($scope, $http,  user);
	}
	
	function flash($rootScope) {
		return {

			pop: function(message) {
				switch(message.type) {
				case 'success':
					toastr.success(message.body, message.title);
					break;
				case 'info':
					toastr.info(message.body, message.title);
					break;
				case 'warning':
					toastr.warning(message.body, message.title);
					break;
				case 'error':
					toastr.error(message.body, message.title);
					break;
				}
			}
		};
	}
}







